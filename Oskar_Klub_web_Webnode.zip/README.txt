OSKAR KLUB — WEB
================
Hotová statická šablona webu v černé / bílé / šedé / zlaté.

STRUKTURA:
index.html       O baru / úvod
akce.html        Kalendář akcí
menu.html        Nápojový lístek
galerie.html     Fotogalerie
rezervace.html   Kontakt + rezervace
style.css        Vizuální styl
assets/          Obrázky vytvořené pro Oskar Klub

WEBNODE:
Webnode nepodporuje klasický import ZIPu jako zdrojového kódu. Nejpraktičtější je vytvořit ve Webnode stránky se stejnými názvy a použít tento balíček jako předlohu. Webnode podporuje vlastní HTML bloky a externí widgety; u novějších projektů je vložení HTML do těla dostupné v prémiových balíčcích. Rezervační formulář lze následně nahradit Webnode formulářem nebo rezervačním widgetem.
